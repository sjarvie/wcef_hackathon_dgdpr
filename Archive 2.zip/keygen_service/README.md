# KeyGen service

### Running the service
``` 
python3 app.py
```
