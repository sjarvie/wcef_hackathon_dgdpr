# !/bin/sh

curl localhost:8888/hello_world
