# !/bin/sh

curl -H "Content-Type: application/json" -X POST -d '{"username":"xyz","password":"xyz"}' http://localhost:8888/nucypher_test_handler

